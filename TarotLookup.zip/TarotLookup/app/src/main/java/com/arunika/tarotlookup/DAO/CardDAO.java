package com.arunika.tarotlookup.DAO;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.arunika.tarotlookup.Database.DBHelper;
import com.arunika.tarotlookup.Model.Card;

import java.util.ArrayList;

public class CardDAO {

    private static Context context;
    private static SQLiteDatabase Database;
    private static DBHelper DBHelper;

    private static CardDAO instance;
    public static synchronized CardDAO getInstance(Context context) {
        if (instance == null) {
            instance = new CardDAO(context);
            DBHelper.onUpgrade(Database,1,2);
        }
        return instance;
    }
    private CardDAO(Context context) {
        DBHelper = DBHelper.getInstance(context);
        this.context = context;
        try {
            Database = DBHelper.getWritableDatabase(); // open the database
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static Card getCard(String name) {
        Card card = null;
        String query = "SELECT * FROM " + DBHelper.TABLE_CARD
                + " WHERE " + DBHelper.COLUMN_NAME + " = '"+name+"';";
        Cursor cursor = Database.rawQuery(query,null);
        if (cursor.moveToFirst()) {
            card = new Card();
            //get card attributes from db
            card.setName(cursor.getString(cursor.getColumnIndex(DBHelper.COLUMN_NAME)));
            card.setFwd(cursor.getString(cursor.getColumnIndex(DBHelper.COLUMN_FWD)));
            card.setRev(cursor.getString(cursor.getColumnIndex(DBHelper.COLUMN_REV)));
        }
        cursor.close();
        return card;
    }

    public static ArrayList<String> getCardNameList() {
        ArrayList<String> nameList = new ArrayList<String>();
        String query = "SELECT  "+ DBHelper.COLUMN_NAME +" FROM "
                + DBHelper.TABLE_CARD+ " WHERE 1=1;" ;
        Cursor cursor = Database.rawQuery(query, null);
        try {
            // looping through all rows and adding card name to list
            if (cursor.moveToFirst()) {
                do {
                    nameList.add(cursor.getString(cursor.getColumnIndex(DBHelper.COLUMN_NAME)));
                } while (cursor.moveToNext());
            }
        } finally {
            try {
                cursor.close(); //always close cursor!
            }
            catch (Exception e) {
            }
        }
        return nameList;
    }
}
