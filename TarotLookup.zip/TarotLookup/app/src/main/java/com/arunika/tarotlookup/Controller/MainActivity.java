package com.arunika.tarotlookup.Controller;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import com.arunika.tarotlookup.DAO.CardDAO;
import com.arunika.tarotlookup.Model.Card;
import com.arunika.tarotlookup.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends BaseMenuActivity {

    private ArrayList<Card> cardList;
    CustomAdapter customAdapter;
    private SpeechRecognizer speechRecognizer;
    private int permission = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //get saved card list from previous state
        SharedPreferences preferences = getSharedPreferences("TAROT_LOOKUP_PREFS", 0);
        if (preferences.contains("savedCardList")) {
            final Gson gson = new Gson();
            Type type = new TypeToken<List<Card>>(){}.getType();
            cardList = gson.fromJson(preferences.getString("savedCardList", ""), type);
        }
        else {
            cardList = new ArrayList<>();
        }
        initializeSpeechRecognizer();

        //initialize list view
        ListView listView = (ListView) findViewById(R.id.listView);
        customAdapter = new CustomAdapter(this,cardList,this);
        listView.setAdapter(customAdapter);

        //microphone button listener
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setAlpha((float)0.7);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //ask for audio recording permissions
                if(ContextCompat.checkSelfPermission(MainActivity.this,
                        Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestAudioPermission();
                }
                //activate microphone for listening
                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
                speechRecognizer.startListening(intent);
            }
        });
    }

    //called when activity is paused, killed by OS or closed by user
    @Override
    protected void onPause() {

        super.onPause();

        SharedPreferences preferences = getSharedPreferences("TAROT_LOOKUP_PREFS",MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        /**
         * Usually, sharedPref only allows storing String var
         * GSON allows storing objects in shared preferences
         * GSON stores it in JSON format
         * currentUser object will now be accessible from every activity
         */
        Gson gson = new Gson();
        String savedCardList = gson.toJson(cardList);
        editor.putString("savedCardList", savedCardList);
        editor.apply();
    }

    @Override
    protected void onResume() {
        super.onResume();
        //get currently logged in user from stored preference
        SharedPreferences preferences = getSharedPreferences("TAROT_LOOKUP_PREFS", 0);
        if (preferences.contains("savedCardList")) {
            final Gson gson = new Gson();
            Type type = new TypeToken<List<Card>>(){}.getType();
            cardList = gson.fromJson(preferences.getString("savedCardList", ""), type);
        }
        else {
            cardList = new ArrayList<>();
        }
        //initialize list view
        ListView listView = (ListView) findViewById(R.id.listView);
        customAdapter = new CustomAdapter(this,cardList,this);
        listView.setAdapter(customAdapter);

    }


    //Collects voice input, turns to text and relays for main processing
    private void initializeSpeechRecognizer() {
        if(SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override
                public void onReadyForSpeech(Bundle params) {
                }

                @Override
                public void onBeginningOfSpeech() {

                }

                @Override
                public void onRmsChanged(float rmsdB) {

                }

                @Override
                public void onBufferReceived(byte[] buffer) {

                }

                @Override
                public void onEndOfSpeech() {

                }

                @Override
                public void onError(int error) {

                }

                /* Collect results (voice input) and send for main processing */
                @Override
                public void onResults(Bundle bundle) {
                    List<String> results = bundle.getStringArrayList(
                            SpeechRecognizer.RESULTS_RECOGNITION
                    );
                    processResult(results.get(0));
                }

                @Override
                public void onPartialResults(Bundle partialResults) {

                }

                @Override
                public void onEvent(int eventType, Bundle params) {

                }
            });
        }
    }

    /* IMPORTANT: matches voice input to tarot card name in DB and displays it */
    private void processResult(String spokenName) {
        spokenName = spokenName.toLowerCase();
        //clear list if user says clear/delete
        if(spokenName.indexOf("clear")==0 || spokenName.indexOf("delete")==0) {
            cardList.clear();
            customAdapter.notifyDataSetChanged();
        }
        else {
            //Find card in DB
            Card card = null;
            ArrayList<String> cardNameList = CardDAO.getInstance(this).getCardNameList();
            for(String cardName : cardNameList) {
                if(spokenName.indexOf(cardName.toLowerCase()) >= 0) {
                    card = CardDAO.getInstance(this).getCard(cardName);
                    break;
                }
            }
            if(card == null) //no card with spoken name found, tell user to try again
            {
                Toast.makeText(this, "Card Name not recognized. Please try again.", Toast.LENGTH_LONG).show();
            }
                else {
                cardList.add(card);
                customAdapter.notifyDataSetChanged();
            }
        }
    }

//********************************** ANDROID PERMISSIONS **********************************//

    //Displays permission rationale and/or request for permission popup
    private void requestAudioPermission() {
        //User has denied it before, show rationale
        if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                Manifest.permission.RECORD_AUDIO)) {

            new AlertDialog.Builder(this)
                    .setTitle("Audio Recording Permission Needed")
                    .setMessage("Microphone permission needed to record speech input for Tarot card look up")
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(MainActivity.this,
                                    new String[] {Manifest.permission.RECORD_AUDIO}, permission);
                        }
                    })
                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .create().show();

        }
        //First time, ask user for permission directly
        else {
            ActivityCompat.requestPermissions(this,
                    new String[] {Manifest.permission.RECORD_AUDIO}, permission);
        }
    }

    //Notifies user in case he denied permission permanently ("Don't Ask Again")
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == permission)  {
            if (grantResults.length <= 0 || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission DENIED : Enable Permissions in Your App Manager", Toast.LENGTH_LONG).show();
            }
        }
    }



}
