package com.arunika.tarotlookup.Controller;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import com.arunika.tarotlookup.R;

/** PLEASE NOTE:
 *  This class creates the three-dot nav menu in the action bar for accessing the Help link
 */
public class BaseMenuActivity extends AppCompatActivity {
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.mymenu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.help: displayHelp();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public void displayHelp() {
        //popup help/about
        new AlertDialog.Builder(this)
                .setTitle("Help")
                .setMessage("1. Tap the microphone icon and (after the beep) say the name of the Tarot Card* you want to find. \n2. Tap and say 'Clear' or 'Delete' to clear the current list of Cards. \n\n* Any of the 78 Cards from the Rider-Waite Deck Only.\n**Only Forward/Reverse divinatory meanings are mentioned, taken from the Rider-Waite Tarot Handbook published by the U.S. Games Systems INC.")
                .setNegativeButton("Got it!", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                })
                .create().show();
    }
}
