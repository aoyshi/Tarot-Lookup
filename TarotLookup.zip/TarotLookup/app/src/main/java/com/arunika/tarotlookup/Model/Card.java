package com.arunika.tarotlookup.Model;

public class Card {
    String name;
    String fwd;
    String rev;

    public Card(String name,String fwd,String rev) {
        this.name = name;
        this.fwd = fwd;
        this.rev = rev;
    }

    public Card() {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFwd() {
        return fwd;
    }

    public void setFwd(String fwd) {
        this.fwd = fwd;
    }

    public String getRev() {
        return rev;
    }

    public void setRev(String rev) {
        this.rev = rev;
    }
}
