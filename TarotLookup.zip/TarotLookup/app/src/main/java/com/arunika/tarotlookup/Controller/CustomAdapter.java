package com.arunika.tarotlookup.Controller;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.arunika.tarotlookup.Model.Card;
import com.arunika.tarotlookup.R;
import java.util.ArrayList;

public class CustomAdapter extends BaseAdapter {
    private LayoutInflater inflater;
    private ArrayList<Card> cardList;
    private Activity activity;
    private class ViewHolder {
        TextView cardNameTextView;
        TextView fwdTextView;
        TextView revTextView;
        TextView fwdTitleTextView;
        TextView revTitleTextView;
    }

    public CustomAdapter(Context context, ArrayList<Card> cardList, Activity activity) {
        super();
        inflater = LayoutInflater.from(context);
        this.cardList = cardList;
        this.activity= activity;
    }
    @Override
    public int getCount() {
        if (cardList != null) { return cardList.size(); }
        else { return 0; }
    }
    @Override
    public Card getItem(int position) {
        return cardList.get(position);
    }
    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        CustomAdapter.ViewHolder holder = new CustomAdapter.ViewHolder();
        convertView = inflater.inflate(R.layout.list_item, null);
        final Card card = getItem(position);

        holder.cardNameTextView = (TextView) convertView.findViewById(R.id.cardName);
        holder.fwdTitleTextView = (TextView) convertView.findViewById(R.id.fwdTitle);
        holder.revTitleTextView = (TextView) convertView.findViewById(R.id.revTitle);
        holder.fwdTextView = (TextView) convertView.findViewById(R.id.fwdDesc);
        holder.revTextView = (TextView) convertView.findViewById(R.id.revDesc);

        holder.cardNameTextView.setText(cardList.get(position).getName());
        holder.fwdTitleTextView.setText(R.string.forward_title);
        holder.revTitleTextView.setText(R.string.reverse_title);
        holder.fwdTextView.setText(cardList.get(position).getFwd());
        holder.revTextView.setText(cardList.get(position).getRev());
        return convertView;
    }
}
